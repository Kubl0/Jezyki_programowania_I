import akka.actor.*

object Organizator {
  case class UstawMaksCyk(maksCyk: Int) {
    assert(maksCyk > 0)
  }
  case object Cyk
  case class PrzejechanaTrasa(liczbaKm: Int)
  case class Init(ilosc: Int)
}



class Organizator extends Actor with ActorLogging {
  import Organizator.*
  def receive = {
    case UstawMaksCyk(mc) =>
      log.info(s"liczba cyknięć do wykonania: $mc")
      val warsztat = context.actorOf(Props[Warsztat](), "Warsztat")
      context.become(poInicjalizacji(mc, List(), warsztat))
    case _ => // inne pomijamy
  }

  def poInicjalizacji(maksCyk: Int, kierowcy: List[ActorRef], warsztat: ActorRef): Receive = {
    case Cyk =>
      log.info("Cyk")
      kierowcy.foreach(el => el ! Kierowca.Cyk)
      warsztat ! Warsztat.Cyk
    case Init(x) => 
      val kierowcy = List.range(0,x).map(ilosc => {
        context.actorOf(Props(new Kierowca),s"k$ilosc")
      })

      kierowcy.head ! Kierowca.Init(kierowcy)
      kierowcy.head ! Kierowca.PrzygotujAuto

      context.become(poInicjalizacji(maksCyk, kierowcy, warsztat))
  }
}

