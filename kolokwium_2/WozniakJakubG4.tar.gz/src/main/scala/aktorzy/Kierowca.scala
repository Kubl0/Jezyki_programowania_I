import akka.actor.*

object Kierowca {
  case class Init(k: List[ActorRef])
  case object Cyk
  case class PrzygotujAuto(kierowcy: List[ActorRef])
  case class ReakcjaAuta(ov: Option[Int])
  case object PodajTrasę
  case class WynikNaprawy(efekt: Option[ActorRef])

  var km = 0
}

class Kierowca extends Actor with ActorLogging {
  import Kierowca.*
  def receive: Receive = {
    case Init(k) => 
      context.become(wyscig((k), List()))
  }
  def wyscig(kierowcy: List[ActorRef], auta: List[ActorRef]): Receive ={
    case PrzygotujAuto => 
      kierowcy.foreach(el => println(el))

      val auta = List.range(0,10).map(ilosc => {
        context.actorOf(Props(new Samochód),s"s$ilosc")
      })

      auta.foreach(el => println(el))

      context.become(wyscig(kierowcy, auta))
    case Cyk =>
      kierowcy.foreach(el => el ! Samochód.Dalej)
    
    case ReakcjaAuta(ov) => 
      ???
  }
}
